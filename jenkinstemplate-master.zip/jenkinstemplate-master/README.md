# JenkinsTemplate

Install the mysql-connector to execute locally.

```python -m pip install mysql-connector-python```

```pip install boto3```

```npm install -g json2csv```

## Making Executable By Jenkins

* Make your git project public and name your script `job.py`
* Place the Apache 2 license file in your project root.
